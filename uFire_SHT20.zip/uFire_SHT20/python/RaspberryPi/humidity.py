from SHT20 import SHT20

sht = SHT20()
print("%.2f" %sht.humidity())
